# Basic Python Calculator

A simple beginner-level Python project that performs:
- Addition
- Subtraction
- Multiplication
- Division

## Requirements
- Python 3

## How to run
1. Extract this ZIP file.
2. Open a terminal or Command Prompt in the project folder.
3. Run:

   python main.py

No extra packages are required.
